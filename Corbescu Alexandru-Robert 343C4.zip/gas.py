from typing import List, Tuple
from levels import *
from util import check_state, state_eq, p, prints, iswin
import gc
from queue import Queue
from copy import deepcopy

started = 0



"""
#######################################
################ TODOs ################
#######################################
"""

class Plan():
    def __init__(self, ops, states, now):
        self.ops = ops
        self.states = states
        self.now = now
        self.count = 0

def euristica(s_changers, s_goals, s_squares, s_locations, s_indexes):

    s = 0

    for key in s_locations.keys():
        for goal in s_goals:
            if key.color == goal[2]:
                s += (abs(s_locations[key][0] - goal[0]) + abs(s_locations[key][1] - goal[1]))
 
    return s

def euristica2(s_changers, s_goals, s_squares, s_locations, s_indexes):

    s = []

    for key in s_locations.keys():
        for goal in s_goals:
            if key.color == goal[2]:
                s.append( (abs(s_locations[key][0] - goal[0]) + abs(s_locations[key][1] - goal[1])))
 
    return max(s)


def solve(initial_state: List[List[str or int]]) -> Tuple[List[str], List[List[List[str or int]]], int]:

    for key in levels:
        if initial_state == levels[key]:
            limit = DISCOVERED_STATE_LIMITS.get(key, 3)

    p1 = Plan([] ,[], initial_state)
    q = []

    q.append((p1,0))

    all_states = {}

    all_states[0] = []

    while len(q) > 0:

        q[0:len(q)-1].sort(key=lambda x: x[1], reverse=True)
        crt = q.pop(0)[0]
        s_changers, s_goals, s_squares, s_locations, s_indexes = init(crt.now)
        for s_square in s_squares:

            
            if len(q) > max(limit//9, 3):
                if euristica2(s_changers, s_goals, s_squares, s_locations, s_indexes) > 3:
                    break
            sss = euristica(s_changers, s_goals, s_squares, s_locations, s_indexes)

            copy_ops = deepcopy(crt.ops)
            copy_states = deepcopy(crt.states)
            copy_crt = deepcopy(crt.now)
            copy_count = crt.count

            new = press(s_square.color, copy_crt)
            copy_ops.append(s_square.color)
            copy_states.append(crt.now)
            

            if iswin(new):
                copy_states.append(new)
                return (copy_ops, copy_states, len(all_states[0]))
                

            copy_count += crt.count
            copy_count += 1
            if new not in all_states[0]:
                all_states[0].append(new)
                q.append((Plan(copy_ops, copy_states, new), sss))

class Square:
    def __init__(self, x, y, color, direction):
        self.x = x
        self.y = y
        self.color = color
        self.direction = direction
        

def press(color: str, state: List[List[str or int]]) -> List[List[str or int]]:

    global started
    
    changers, goals, squares, locations, indexes = init(state)

    changers, goals, squares, locations, indexes = press_action(color, state, changers, goals, squares, locations, indexes)
    for i in indexes:
        state[i][0] = squares[indexes.index(i)].x
        state[i][1] = squares[indexes.index(i)].y
        state[i][4] = squares[indexes.index(i)].direction
    
    return state

def init(initial_state):

    changers = []
    goals = []
    squares = []
    locations = {}
    indexes = []

    for obj in initial_state:
        if None in obj:
            changers.append((obj[0], obj[1], obj[4]))
        elif 'GOAL' in obj:
            goals.append((obj[0], obj[1], obj[3]))
        else:
            squares.append(Square(obj[0],obj[1],obj[3],obj[4]))
            locations[squares[-1]] = (obj[0], obj[1])
            indexes.append(initial_state.index(obj))


    return changers, goals, squares, locations, indexes

def miscare(moving, changers, goals, squares, locations, indexes, state):
    
    still_moving = True

    for i in indexes:
        state[i][0] = squares[indexes.index(i)].x
        state[i][1] = squares[indexes.index(i)].y
        state[i][4] = squares[indexes.index(i)].direction


    while still_moving:
        
    
        still_moving = False
        for square1 in squares:
            for square2 in squares:
                if locations[square1] == locations[square2] and square1 != square2:
                    if moving != square1 and moving != square2:
                        if moving.direction == '^':
                            square1.y = square1.y + 1
                        elif moving.direction == 'v':
                            square1.y = square1.y - 1
                        elif moving.direction == '<':
                            square1.x = square1.x - 1
                        elif moving.direction == '>':
                            square1.x = square1.x + 1
                        locations[square1] = (square1.x, square1.y)
                        still_moving = True
                                
                    elif moving == square1:
                        if moving.direction == '^':
                            square2.y = square2.y + 1
                        elif moving.direction == 'v':
                            square2.y = square2.y - 1
                        elif moving.direction == '<':
                            square2.x = square2.x - 1
                        elif moving.direction == '>':
                            square2.x = square2.x + 1
                        locations[square2] = (square2.x, square2.y)
                        still_moving = True
                                        
                    elif moving == square2:
                        if moving.direction == '^':
                            square1.y = square1.y + 1
                        elif moving.direction == 'v':
                            square1.y = square1.y - 1
                        elif moving.direction == '<':
                            square1.x = square1.x - 1
                        elif moving.direction == '>':
                            square1.x = square1.x + 1
                        locations[square1] = (square1.x, square1.y)
                        still_moving = True
        
    return changers, goals, squares, locations, indexes                    
                        
def press_action(color, initstate, changers, goals, squares, locations, indexes):

    for square in squares:
        if color == square.color:
            if square.direction == '^':
                square.y = square.y + 1
            elif square.direction == 'v':
                square.y = square.y - 1
            elif square.direction == '<':
                square.x = square.x - 1
            elif square.direction == '>':
                square.x = square.x + 1
            locations[square] = (square.x, square.y)
            changers, goals, squares, locations, indexes = miscare(square, changers, goals, squares, locations, indexes, initstate)

    for change in changers:
        for square in squares:
            if square.x == change[0] and square.y == change[1]:
                square.direction = change[2]
    return changers, goals, squares, locations, indexes



def play(initstate: List[List[str or int]], plan: List[str], small: bool=False):
    

    state = initstate
    print(p(state, small))
    
    for action in plan:
        state = press(action, state)
        print(p(state, False))
